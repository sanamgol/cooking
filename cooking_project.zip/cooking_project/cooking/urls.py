
from django.contrib import admin
from django.urls import path, include
from django.conf.urls.static import static
from django.conf import settings

urlpatterns = [
    path('admin/', admin.site.urls),
     path('accounts/',include('apps.accounts.urls',namespace='accounts')),
     path('contact/',include('apps.contact.urls',namespace='contact')),
     path('cookingclasses/',include('apps.CookingClasses.urls',namespace='cookingclasses')),
     path('gallery/',include('apps.gallery.urls',namespace='gallery')),
      path('',include('apps.mainapp.urls',namespace='mainapp')),
      path('orders/',include('apps.orders.urls',namespace='orders')),
      path('blog/',include('apps.recipes.urls',namespace='recipes')),
      path('search/',include('apps.search.urls',namespace='search')),
     
     
     
    
]+static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
