# orders/serializers.py
from rest_framework import serializers
from .models import FoodOrder, Address

class AddressSerializer(serializers.ModelSerializer):
    class Meta:
        model = Address
        fields = ['neighborhood', 'street', 'alley', 'plate_number']

class FoodOrderSerializer(serializers.ModelSerializer):
    address = AddressSerializer(read_only=True)

    class Meta:
        model = FoodOrder
        fields = ['id', 'recipe', 'quantity', 'price', 'address']
