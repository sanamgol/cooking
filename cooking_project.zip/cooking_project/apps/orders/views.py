from django.shortcuts import render
from django.http import HttpResponseRedirect
from django.urls import reverse
from .forms import OrderForm
from .models import FoodOrder, Address

def order_form(request):
    context = {}

    if request.method == "POST":
        form = OrderForm(request.POST)
        if form.is_valid():
            data = form.cleaned_data

            order = FoodOrder()
            order.recipe = data['recipe']
            order.quantity = data['quantity']
            order.price = data['price']
            order.save()

         
            address = Address()
            address.user = request.user
            address.neighborhood = data['neighborhood']
            address.street = data['street']
            address.alley = data['alley']
            address.plate_number = data['plate_number']
            address.save()

            # بعد از ذخیره، redirect به صفحه‌ای که دوست داری
            return HttpResponseRedirect(reverse('order_success'))

    else:
        form = OrderForm()

    context['form'] = form
    return render(request, "orders/order_form.html", context)
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from .models import FoodOrder, Address
from .forms import OrderForm
from .serializers import FoodOrderSerializer, AddressSerializer  

class OrderAPI(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        form = OrderForm(request.data)
        if form.is_valid():
            data = form.cleaned_data

            # ذخیره سفارش غذا
            order = FoodOrder.objects.create(
                recipe=data['recipe'],
                quantity=data['quantity'],
                price=data['price']
            )

            # ذخیره آدرس
            address = Address.objects.create(
                user=request.user,
                neighborhood=data['neighborhood'],
                street=data['street'],
                alley=data['alley'],
                plate_number=data['plate_number']
            )

       
            order_data = {
                "order_id": order.id,
                "recipe": order.recipe.title,
                "quantity": order.quantity,
                "price": float(order.price),
                "address": {
                    "neighborhood": address.neighborhood,
                    "street": address.street,
                    "alley": address.alley,
                    "plate_number": address.plate_number
                }
            }

            return Response(order_data, status=status.HTTP_201_CREATED)

        return Response({"errors": form.errors}, status=status.HTTP_400_BAD_REQUEST)
