from django import forms
from apps.recipes.models import Recipe


class OrderForm(forms.Form):
    # فرم سفارش غذا
    recipe = forms.ModelChoiceField(queryset=Recipe.objects.all(), label='دستور آشپزی')
    quantity = forms.IntegerField(min_value=1, initial=1, label='تعداد سفارش')
    price = forms.DecimalField(max_digits=10, decimal_places=2, label='قیمت')

    # فرم آدرس
    neighborhood = forms.CharField(max_length=200, label='محله')
    street = forms.CharField(max_length=200, label='خیابان')
    alley = forms.CharField(max_length=200, required=False, label='کوچه')
    plate_number = forms.CharField(max_length=20, label='شماره پلاک')

    # اعتبارسنجی سفارشی برای تعداد سفارش
    def clean_quantity(self):
        quantity = self.cleaned_data.get('quantity')
        if quantity < 1:
            raise forms.ValidationError("تعداد سفارش باید حداقل 1 باشد.")
        return quantity

    # اعتبارسنجی برای قیمت
    def clean_price(self):
        price = self.cleaned_data.get('price')
        if price <= 0:
            raise forms.ValidationError("قیمت باید بزرگتر از صفر باشد.")
        return price

    # اعتبارسنجی برای محله
    def clean_neighborhood(self):
        neighborhood = self.cleaned_data.get('neighborhood')
        if not neighborhood.strip():
            raise forms.ValidationError("محله نمی‌تواند خالی باشد.")
        return neighborhood

    # اعتبارسنجی برای خیابان
    def clean_street(self):
        street = self.cleaned_data.get('street')
        if not street.strip():
            raise forms.ValidationError("خیابان نمی‌تواند خالی باشد.")
        return street

    def clean_alley(self):
        alley = self.cleaned_data.get('alley')
        if alley and len(alley) > 100:
            raise forms.ValidationError("کوچه نمی‌تواند طولانی‌تر از 100 کاراکتر باشد.")
        return alley

    # اعتبارسنجی برای شماره پلاک
    def clean_plate_number(self):
        plate_number = self.cleaned_data.get('plate_number')
        if not plate_number.strip():
            raise forms.ValidationError("شماره پلاک نمی‌تواند خالی باشد.")
        return plate_number

    # اعتبارسنجی برای انتخاب دستور آشپزی
    def clean_recipe(self):
        recipe = self.cleaned_data.get('recipe')
        if not recipe:
            raise forms.ValidationError("یک دستور آشپزی باید انتخاب شود.")
        return recipe



