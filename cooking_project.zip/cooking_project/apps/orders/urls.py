from django.urls import path
from .views import order_form, OrderAPI

app_name = 'order'

urlpatterns = [
    # ویو کلاسیک با فرم HTML
    path('order/', order_form, name='order_form'),

    # ویو API
    path('api/order/', OrderAPI.as_view(), name='order_api'),
]
