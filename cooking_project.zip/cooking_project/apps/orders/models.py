from django.db import models
from django.contrib.auth.models import User
from apps.recipes.models import Recipe


class Address(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name='کاربر')
    neighborhood = models.CharField(max_length=200, verbose_name='محله')
    street = models.CharField(max_length=200, verbose_name='خیابان')
    alley = models.CharField(max_length=200, blank=True, null=True, verbose_name='کوچه')
    plate_number = models.CharField(max_length=20, verbose_name='شماره پلاک')

    def __str__(self):
        return f"{self.user.username} - {self.street}"

    class Meta:
        verbose_name = 'آدرس'
        verbose_name_plural = 'آدرس‌ها'
        db_table = 't_Address'

class FoodOrder(models.Model):
    recipe = models.ForeignKey(Recipe, on_delete=models.CASCADE, verbose_name='دستور آشپزی')
    quantity = models.PositiveIntegerField(default=1, verbose_name='تعداد سفارش')
    sold_count = models.PositiveIntegerField(default=0, verbose_name='تعداد فروخته شده')
    price = models.DecimalField(max_digits=10, decimal_places=2, default=0, verbose_name='قیمت')


    def __str__(self):
        return f"{self.recipe.title} (x{self.quantity}) - {self.price} تومان"

    class Meta:
        verbose_name = 'سفارش غذا'
        verbose_name_plural = 'سفارشات غذا'
        db_table = 't_FoodOrder'
