from django.contrib import admin
from .models import Address, FoodOrder

@admin.register(Address)
class AddressAdmin(admin.ModelAdmin):
    list_display = ('user', 'neighborhood', 'street', 'alley', 'plate_number')
    search_fields = ('user__username', 'street', 'neighborhood')
    list_filter = ('neighborhood',)


@admin.register(FoodOrder)
class FoodOrderAdmin(admin.ModelAdmin):
    list_display = ('recipe', 'quantity', 'sold_count')
    search_fields = ('recipe__title',)
    list_filter = ('recipe',)
