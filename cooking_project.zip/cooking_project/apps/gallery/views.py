from django.shortcuts import render, get_object_or_404
from django.views.generic import ListView
from .models import Gallery
from apps.recipes.models import Recipe

# ---------------- Template Views ----------------
class GalleryListView(ListView):
    model = Gallery
    template_name = "gallery/gallery_list.html"
    context_object_name = "images"
    paginate_by = 10  # می‌تونی تغییر بدی

    def get_queryset(self):
        recipe_id = self.kwargs.get('recipe_id')
        return Gallery.objects.filter(recipe_id=recipe_id).order_by('-id')

# ---------------- API Views ----------------
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import AllowAny
from .serializers import GallerySerializer

class GalleryListAPI(APIView):
    permission_classes = [AllowAny]

    def get(self, request, recipe_id):
        gallery_items = Gallery.objects.filter(recipe_id=recipe_id).order_by('-id')
        serializer = GallerySerializer(gallery_items, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

# ---------------- Detail View Template ----------------
from django.shortcuts import render
from .models import Gallery

def gallery_list(request):
    images = Gallery.objects.select_related('recipe').order_by('-created_at')
    return render(request, 'gallery/gallery_list.html', {'images': images})
