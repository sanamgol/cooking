from django.db import models
from apps.recipes.models import Recipe

class Gallery(models.Model):
    recipe = models.ForeignKey(
        Recipe,
        on_delete=models.CASCADE,
        related_name='recipe_gallery',  
        verbose_name='دستور پخت مرتبط'
    )
    image = models.ImageField(upload_to='class_gallery/', verbose_name='عکس گالری')
    caption = models.CharField(max_length=200, blank=True, null=True, verbose_name='توضیح عکس')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"عکس {self.recipe.title}"
