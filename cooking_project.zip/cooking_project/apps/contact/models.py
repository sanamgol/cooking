from django.db import models
from django.utils import timezone
# apps/contact/models.py
from django.db import models

class ContactMessage(models.Model):
    full_name = models.CharField(max_length=100, verbose_name='نام کامل')
    email = models.EmailField(verbose_name='ایمیل')
    phone = models.CharField(max_length=20, blank=True, null=True, verbose_name='تلفن')
    contact_type = models.CharField(max_length=50, blank=True, null=True, verbose_name='نوع تماس')
    message = models.TextField(verbose_name='پیام')
    attachment = models.FileField(upload_to='attachments/', blank=True, null=True, verbose_name='فایل پیوست')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.full_name} - {self.email}"
