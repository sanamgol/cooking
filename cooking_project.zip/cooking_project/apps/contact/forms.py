


from django import forms
from .models import ContactMessage

class ContactMessageForm(forms.ModelForm):
    class Meta:
        model = ContactMessage
        fields =  ['full_name', 'email', 'phone', 'contact_type', 'message', 'attachment']
        widgets = {
             'full_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'نام و نام خانوادگی'}),
            'email': forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'ایمیل'}),
            'phone': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'شماره موبایل'}),
            'subject': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'موضوع'}),
          'message': forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'پیام', 'rows': 5}),
            'contact_type': forms.Select(attrs={'class': 'form-select'}),
            'attachment': forms.ClearableFileInput(attrs={'class': 'form-control'}),
        }

    def clean(self):
        cleaned = super().clean()
        email = cleaned.get('email')
        phone = cleaned.get('phone')

        if not email and not phone:
            raise forms.ValidationError("لطفاً حداقل یکی از ایمیل یا شماره موبایل را وارد کنید.")
        return cleaned




















