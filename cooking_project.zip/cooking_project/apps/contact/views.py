from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import AllowAny
from .models import ContactMessage
from .forms import ContactMessageForm
from .serializers import ContactMessageSerializer
from django.shortcuts import render
from django.contrib import messages
from django.http import JsonResponse

def contact(request):
    if request.method == "POST" and request.headers.get("x-requested-with") == "XMLHttpRequest":
        form = ContactMessageForm(request.POST, request.FILES)
        if form.is_valid():
            contact_msg = form.save()
            return JsonResponse({'success': True, 'full_name': contact_msg.full_name})
        else:
            return JsonResponse({'success': False, 'errors': form.errors}, status=400)
    else:
        form = ContactMessageForm()
    return render(request, "contact/contact_form.html", {"form": form})
# ---------------- API View ----------------
class ContactMessageAPI(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = ContactMessageSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({
                "message": "پیام شما با موفقیت ارسال شد ✅",
                "data": serializer.data
            }, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
