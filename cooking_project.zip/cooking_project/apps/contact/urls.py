from django.urls import path
from .views import contact, ContactMessageAPI

app_name = 'contact'

urlpatterns = [
    path('', contact, name='contact_form'),
    path('api/send/', ContactMessageAPI.as_view(), name='contact_api'),
]



