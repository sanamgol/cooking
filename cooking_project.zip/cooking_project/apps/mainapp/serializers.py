from rest_framework import serializers

class IndexSerializer(serializers.Serializer):
    media_url = serializers.CharField()
    imageName = serializers.CharField()
    user_name = serializers.CharField()
