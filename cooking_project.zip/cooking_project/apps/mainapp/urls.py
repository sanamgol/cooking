from django.urls import path
from .views import index, IndexAPI

app_name = 'mainapp'

urlpatterns = [
    # ---------------- Template View ----------------
    path('', index, name='index'),

    # ---------------- API View ----------------
    path('api/index/', IndexAPI.as_view(), name='index_api'),
]
