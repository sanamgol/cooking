
from django.shortcuts import render
from django.conf import settings
from django.contrib.auth.models import User


def index(request):
   username='مهمان'
   if request.user.is_authenticated:
          username=request.user.username
   request.session['user_name']=username
   context={
          'media_url':settings.MEDIA_URL,
          "imageName":'Darsman-Instagram.webp',
   }
   return render(request,'mainapp/index.html',context)





def media_admin(request):
   return  { 'media_url':settings.MEDIA_URL,}

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import AllowAny

class IndexAPI(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        context = {
            'media_url': settings.MEDIA_URL,
            'imageName': 'Darsman-Instagram.webp',
            'user_name': request.user.username if request.user.is_authenticated else 'مهمان'
        }
        return Response(context)
