
from rest_framework import serializers
from .models import CookingClass, ClassGallery

class ClassGallerySerializer(serializers.ModelSerializer):
    class Meta:
        model = ClassGallery
        fields = ['id', 'cooking_class', 'image']

class CookingClassSerializer(serializers.ModelSerializer):
    gallery = ClassGallerySerializer(source='classgallery_set', many=True, read_only=True)

    class Meta:
        model = CookingClass
        fields = [
            'id',
            'title',
            'image_name',
            'date_time',
            'location',
            'teacher',
            'description',
            'report_text',
            'views_count',
            'created_at',
            'status',
            'class_status',
            'gallery', 
        ]
