from django.urls import path
from .views import ShowClassList, ShowClassReport, CookingClassListAPI, CookingClassDetailAPI

app_name = 'CookingClasses'

urlpatterns = [
    # Template Views
    path('', ShowClassList.as_view(), name='class_list'),
    path('<int:pk>/report/', ShowClassReport.as_view(), name='class_report'),

    # API Views
    path('api/classes/', CookingClassListAPI.as_view(), name='api_class_list'),
    path('api/classes/<int:pk>/', CookingClassDetailAPI.as_view(), name='api_class_detail'),
]
