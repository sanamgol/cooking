from django.db import models
from django.contrib.auth.models import User

class ClassStatus(models.Model):
    title = models.CharField(max_length=100, verbose_name='عنوان وضعیت کلاس')

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = 'وضعیت کلاس'
        verbose_name_plural = 'وضعیت کلاس‌ها'
        db_table = 't_ClassStatus'


def upload_cookingclass(instance,filename):
    return f"images/cookingclass/{filename}"


class CookingClass(models.Model):
    title = models.CharField(max_length=200, verbose_name='عنوان کلاس')
    image_name=models.ImageField(upload_to=upload_cookingclass,max_length=50,verbose_name="عکس کلاس",default="default.jpg")
    date_time = models.DateTimeField(verbose_name='تاریخ و ساعت')
    location = models.CharField(max_length=200, verbose_name='مکان')
    teacher = models.CharField(max_length=200, verbose_name='مدرس')
    description = models.TextField(verbose_name='توضیحات')
    report_text = models.TextField(blank=True, null=True, verbose_name='متن گزارش')
    views_count = models.PositiveIntegerField(default=0, verbose_name='تعداد بازدید')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='تاریخ ایجاد')
    status = models.BooleanField(default=True, verbose_name='فعال/غیرفعال')
    class_status = models.ForeignKey(ClassStatus, on_delete=models.SET_NULL, null=True, blank=True, verbose_name='وضعیت کلاس')

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = 'کلاس آشپزی'
        verbose_name_plural = 'کلاس‌های آشپزی'
        db_table = 't_CookingClass'


def upload_gallery_cookingclass(instance,filename):
    return f"images/cookingclass/report/{instance.cooking_class.id}/{filename}"



class ClassGallery(models.Model):
    cooking_class = models.ForeignKey(CookingClass, on_delete=models.CASCADE, verbose_name='کلاس آشپزی')
    image = models.ImageField(upload_to=upload_gallery_cookingclass, verbose_name='تصویر کلاس')

    def __str__(self):
        return f"Image for {self.cooking_class.title}"

    class Meta:
        verbose_name = 'گالری کلاس'
        verbose_name_plural = 'گالری کلاس‌ها'
        db_table = 't_ClassGallery'
