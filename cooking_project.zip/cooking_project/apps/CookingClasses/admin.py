from django.contrib import admin

# Register your models here.
from django.contrib import admin
from .models import ClassStatus, CookingClass, ClassGallery

@admin.register(ClassStatus)
class ClassStatusAdmin(admin.ModelAdmin):
    list_display = ('title',)
    search_fields = ('title',)


@admin.register(CookingClass)
class CookingClassAdmin(admin.ModelAdmin):
    list_display = ('title', 'date_time', 'location', 'teacher', 'status', 'views_count')
    search_fields = ('title', 'teacher', 'location')
    list_filter = ('status', 'class_status')


@admin.register(ClassGallery)
class ClassGalleryAdmin(admin.ModelAdmin):
    list_display = ('cooking_class', 'image')
    search_fields = ('cooking_class__title',)
    list_filter = ('cooking_class',)
