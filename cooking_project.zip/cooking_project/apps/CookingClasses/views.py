from django.shortcuts import render
from django.views.generic.list import ListView
from django.views.generic import DeleteView
from django.conf import settings
from django.http import Http404
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import AllowAny
from .models import CookingClass
from .serializers import CookingClassSerializer
import os


class ShowClassList(ListView):
    model = CookingClass
    template_name = "cookingclasses/class_list.html"
    context_object_name = "classes"
    ordering = ['-date_time']
    queryset = CookingClass.objects.filter(status=True)
    paginate_by = 2


class ShowClassReport(DeleteView):
    model = CookingClass
    template_name = "cookingclasses/class_report.html"
    context_object_name = "cooking_class"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        pk = self.kwargs['pk']
        try:
            cookingclass = CookingClass.objects.get(id=pk)
            cookingclass.views_count += 1
            cookingclass.save()

            path = os.path.join(settings.MEDIA_ROOT, 'images', 'cookingclass', 'report', str(pk))
            if os.path.isdir(path):
                context['image_list'] = os.listdir(path)
            return context
        except CookingClass.DoesNotExist:
            raise Http404("class not found")


class CookingClassListAPI(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        classes = CookingClass.objects.filter(status=True).order_by('-date_time')
        serializer = CookingClassSerializer(classes, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)


class CookingClassDetailAPI(APIView):
    permission_classes = [AllowAny]

    def get(self, request, pk):
        try:
            cookingclass = CookingClass.objects.get(pk=pk, status=True)
        except CookingClass.DoesNotExist:
            return Response({"error": "کلاس پیدا نشد"}, status=status.HTTP_404_NOT_FOUND)
        serializer = CookingClassSerializer(cookingclass)
        return Response(serializer.data, status=status.HTTP_200_OK)
