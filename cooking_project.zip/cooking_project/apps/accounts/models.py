from django.db import models
from django.core.validators import RegexValidator, EmailValidator
from django.utils import timezone


IRAN_PHONE_REGEX = RegexValidator(
    regex=r'^09\d{9}$',
    message="شماره موبایل باید با 09 شروع شود و 11 رقم باشد. مثل 09123456789"
)

class ContactMessage(models.Model):
    CONTACT_TYPES = [
        ('general', 'عمومی'),
        ('support', 'پشتیبانی'),
        ('sales', 'فروش'),
        ('feedback', 'بازخورد'),
        ('bug', 'گزارش اشکال'),
        ('other', 'سایر'),
    ]

    full_name = models.CharField("نام کامل", max_length=200)
    email = models.EmailField("ایمیل", validators=[EmailValidator()], blank=True, null=True)
    phone = models.CharField("موبایل", validators=[IRAN_PHONE_REGEX], max_length=11, blank=True, null=True)
    subject = models.CharField("موضوع", max_length=200, blank=True)
    message = models.TextField("پیام", help_text="متن پیغام کاربر")
    contact_type = models.CharField("نوع تماس", max_length=20, choices=CONTACT_TYPES, default='general')
    attachment = models.FileField("فایل پیوست", upload_to='contact_attachments/', blank=True, null=True)
    is_resolved = models.BooleanField("رسیدگی شده", default=False)
    created_at = models.DateTimeField("ایجاد شده", default=timezone.now)
    updated_at = models.DateTimeField("آخرین تغییر", auto_now=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = "پیام تماس"
        verbose_name_plural = "پیام‌های تماس"

    def __str__(self):
        return f"{self.full_name} — {self.subject or 'بدون موضوع'}"

from django.db import models
from django.contrib.auth.models import User

class PersonModel(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, verbose_name="کاربر")
    full_name = models.CharField(max_length=100, verbose_name="نام کامل")
    age = models.PositiveIntegerField(null=True, blank=True, verbose_name="سن")
    phone_number = models.CharField(max_length=20, blank=True, null=True, verbose_name="شماره تلفن")

    def __str__(self):
        return self.full_name

    class Meta:
        verbose_name = "شخص"
        verbose_name_plural = "اشخاص"


