# accounts/urls.py
from django.urls import path
from .views import (
    RegisterUserView, LoginUserView, LogoutUserView,
    RegisterUserAPI, LoginUserAPI, PersonAdd
)
from django.urls import path, reverse_lazy
from django.contrib.auth import views as auth_views

app_name = 'accounts'


from django.urls import path
from django.contrib.auth import views as auth_views
from . import views
app_name = 'accounts'

urlpatterns = [
    
      path('register/', RegisterUserView.as_view(), name='register'),
    path('login/', LoginUserView.as_view(), name='login'),
    path('logout/', LogoutUserView.as_view(), name='logout'),
    
    
    path('password/change/', views.change_password, name='password_change'),
    path('password/change/done/', auth_views.PasswordChangeDoneView.as_view(template_name='accounts/change_password_done.html'), name='password_change_done'),

    # ---------------------------
    # بازیابی رمز عبور
    # ---------------------------
path('password/reset/', auth_views.PasswordResetView.as_view(
    template_name='accounts/password_reset_form.html',
    success_url=reverse_lazy('accounts:password_reset_done')  # ← اضافه شد
), name='password_reset'),

 path('password/reset/done/', auth_views.PasswordResetDoneView.as_view(
    template_name='accounts/password_reset_done.html'
), name='password_reset_done'),


    path('password/reset/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(template_name='accounts/password_reset_confirm.html'), name='password_reset_confirm'),
    path('password/reset/complete/', auth_views.PasswordResetCompleteView.as_view(template_name='accounts/password_reset_complete.html'), name='password_reset_complete'),
]
 