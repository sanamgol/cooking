# accounts/views.py
from django.shortcuts import render, redirect
from django.views import View
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout

# DRF Imports
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import AllowAny
from rest_framework.authtoken.models import Token

from .serializers import UserSerializer, PersonSerializer
from .models import PersonModel
from .forms import RegisterUserForm, LoginUserForm

# ----------------------------
# Template Views
# ----------------------------
class RegisterUserView(View):
    def get(self, request, *args, **kwargs):
        form = RegisterUserForm()
        return render(request, "accounts/register.html", {"form": form})

    def post(self, request, *args, **kwargs):
        form = RegisterUserForm(request.POST)
        if form.is_valid():
            data = form.cleaned_data
            user = User(
                first_name=data['first_name'],
                last_name=data['last_name'],
                username=data['username']
            )
            user.set_password(data['password1'])
            user.save()
            messages.success(request, 'ثبت نام با موفقیت انجام شد')
            return redirect('mainapp:index')
        messages.error(request, 'اطلاعات وارد شده درست نیست')
        return render(request, "accounts/register.html", {"form": form})


class LoginUserView(View):
    def get(self, request, *args, **kwargs):
        form = LoginUserForm()
        return render(request, "accounts/login.html", {"form": form})

    def post(self, request, *args, **kwargs):
        form = LoginUserForm(request.POST)
        if form.is_valid():
            data = form.cleaned_data
            user = authenticate(username=data['username'], password=data['password'])
            if user:
                login(request, user)
                messages.success(request, 'ورود با موفقیت انجام شد')
                next_url = request.GET.get('next')
                return redirect(next_url or 'mainapp:index')
            messages.warning(request, 'نام کاربری یا رمز عبور اشتباه است')
        else:
            messages.warning(request, 'اطلاعات وارد شده معتبر نمی باشد')
        return render(request, "accounts/login.html", {"form": form})


class LogoutUserView(View):
    def get(self, request, *args, **kwargs):
        logout(request)
        messages.success(request, 'خداحافظ')
        return redirect('mainapp:index')
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth import update_session_auth_hash
from django.shortcuts import render, redirect

def change_password(request):
    if request.method == 'POST':
        form = PasswordChangeForm(user=request.user, data=request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)  # حفظ لاگین بعد تغییر رمز
            return redirect('accounts:password_change_done')
    else:
        form = PasswordChangeForm(user=request.user)
    return render(request, 'accounts/change_password.html', {'form': form})


# ----------------------------
# API Views
# ----------------------------
class RegisterUserAPI(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = UserSerializer(data=request.data)
        if serializer.is_valid():
            serializer.create(serializer.validated_data)
            return Response({"message": "ثبت نام با موفقیت انجام شد"}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class LoginUserAPI(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        username = request.data.get("username")
        password = request.data.get("password")
        user = authenticate(username=username, password=password)
        if user:
            login(request, user)
            return Response({"message": "ورود با موفقیت انجام شد"})
        return Response({"error": "نام کاربری یا رمز عبور اشتباه است"}, status=status.HTTP_401_UNAUTHORIZED)

class PersonAdd(APIView):
    def post(self, request):
        serializer = PersonSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()  # از create داخل سریالایزر استفاده می‌کنه
            return Response({"message": "شخص با موفقیت اضافه شد"}, status=201)
        return Response(serializer.errors, status=400)


# ----------------------------
# Create Token For All Users
# ----------------------------
class CreateTokenForAllUser(APIView):
    def get(self, request):
        for user in User.objects.all():
            Token.objects.get_or_create(user=user)
        return Response(status=status.HTTP_200_OK)
