# accounts/serializers.py
from rest_framework import serializers
from django.contrib.auth.models import User
from .models import PersonModel

# ---------------------------
# User Serializer
# ---------------------------
class UserSerializer(serializers.ModelSerializer):
    password1 = serializers.CharField(write_only=True, required=True)
    password2 = serializers.CharField(write_only=True, required=True)

    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name', 'password1', 'password2']

    def validate(self, attrs):
        if attrs['password1'] != attrs['password2']:
            raise serializers.ValidationError("رمز عبور و تکرار آن مطابقت ندارند")
        return attrs

    def create(self, validated_data):
        user = User(
            username=validated_data['username'],
            first_name=validated_data.get('first_name', ''),
            last_name=validated_data.get('last_name', '')
        )
        user.set_password(validated_data['password1'])
        user.save()
        return user

# ---------------------------
# Person Serializer
# ---------------------------
class PersonSerializer(serializers.ModelSerializer):
    username = serializers.CharField(write_only=True, required=True)
    password = serializers.CharField(write_only=True, required=True)
    
    class Meta:
        model = PersonModel
        fields = ['username', 'password', 'full_name', 'age', 'phone_number']

    def create(self, validated_data):
        from django.contrib.auth.models import User
        username = validated_data.pop('username')
        password = validated_data.pop('password')
        user = User.objects.create_user(username=username, password=password)
        person = PersonModel.objects.create(user=user, **validated_data)
        return person

    def validate_username(self, value):
        from django.contrib.auth.models import User
        if User.objects.filter(username=value).exists():
            raise serializers.ValidationError("این نام کاربری قبلاً ثبت شده است")
        return value
