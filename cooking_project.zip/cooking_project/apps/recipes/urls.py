from django.urls import path
from .views import (
    AuthorListView, AuthorDetailView,
    CategoryListView, CategoryDetailView,
    RecipeListView, RecipeDetailView,
    RecipeCreate, RecipeUpdate, RecipeDelete,recipe_gallery,
    add_rating, download_recipe,
    fun1, like_recipe, index_recipes
)
from django.conf import settings
from django.conf.urls.static import static

app_name = 'recipes'

urlpatterns = [
    # نویسنده‌ها
    path("authors/", AuthorListView.as_view(), name="author_list"),
    path("authors/<int:pk>/", AuthorDetailView.as_view(), name="author_detail"),

    # دسته‌بندی‌ها
    path("categories/", CategoryListView.as_view(), name="category_list"),
    path("categories/<int:id>/", CategoryDetailView.as_view(), name="category_detail"),

    # دستورهای آشپزی
    path("recipes/", RecipeListView.as_view(), name="recipe_list"),

    # افزودن، ویرایش و حذف دستور آشپزی
    path("recipes/add/", RecipeCreate.as_view(), name='recipe_add'),
    path("recipes/update/<int:pk>/", RecipeUpdate.as_view(), name='recipe_update'),
    path("recipes/delete/<int:pk>/", RecipeDelete.as_view(), name='recipe_delete'),
    path('gallery/<slug:slug>/', recipe_gallery, name='recipe_gallery'),
    # لایک کردن رسپی **قبل از slug**
    path("recipes/like_recipe/", like_recipe, name='like_recipe'),

    # جزئیات دستور پخت
    path("recipes/<slug:slug>/", RecipeDetailView.as_view(), name="recipe_detail"),

    # ریت و دانلود PDF
    path("recipes/<int:recipe_id>/rate/", add_rating, name="add_rating"),
    path("pdf_recipe/", download_recipe, name='pdf_recipe'),

    # Paginator
    path("recipes_paginated/", fun1, name='fun1'),

    # صفحه اصلی رسپی‌ها
    path("", index_recipes, name='index'),
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

