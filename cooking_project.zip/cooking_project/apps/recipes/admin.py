# admin.py
from django.contrib import admin
from .models import Author, Category, Recipe,  Rating

@admin.register(Author)
class AuthorAdmin(admin.ModelAdmin):
    list_display = ('first_name', 'last_name', 'email', 'status')
    search_fields = ('first_name', 'last_name', 'email')
    list_filter = ('status',)


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('title',)
    search_fields = ('title',)


@admin.register(Recipe)
class RecipeAdmin(admin.ModelAdmin):
    list_display = ('title', 'author', 'category', 'prep_time', 'status', 'views_count')
    search_fields = ('title', 'author__first_name', 'author__last_name')
    list_filter = ('status', 'category')



@admin.register(Rating)
class RatingAdmin(admin.ModelAdmin):
    list_display = ('recipe', 'user', 'value')
    list_filter = ('value',)
