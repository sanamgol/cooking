from django.db import models
from django.contrib.auth.models import User


class Author(models.Model):
    first_name = models.CharField(max_length=100, verbose_name='نام')
    last_name = models.CharField(max_length=100, verbose_name='نام خانوادگی')
    degree = models.CharField(max_length=200, blank=True, null=True, verbose_name='تحصیلات')
    job_title = models.CharField(max_length=200, blank=True, null=True, verbose_name='عنوان شغلی')
    email = models.EmailField(unique=True, verbose_name='ایمیل')
    phone_number = models.CharField(max_length=20, blank=True, null=True, verbose_name='شماره تلفن')
    slug = models.SlugField(unique=True, verbose_name='اسلاگ')
    status = models.BooleanField(default=True , verbose_name='فعال/غیرفعال')

    def __str__(self):
        return f"{self.first_name} {self.last_name}"

    class Meta:
        verbose_name = 'نویسنده'
        verbose_name_plural = 'نویسندگان'
        db_table = 't_Authors'


class Category(models.Model):
    title = models.CharField(max_length=200, verbose_name='عنوان دسته‌بندی')

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = 'دسته‌بندی'
        verbose_name_plural = 'دسته‌بندی‌ها'
        db_table = 't_Category'


class Recipe(models.Model):
    title = models.CharField(max_length=200, verbose_name='عنوان')
    author = models.ForeignKey("Author", on_delete=models.SET_NULL, null=True, blank=True, verbose_name='نویسنده')
    category = models.ForeignKey("Category", on_delete=models.SET_NULL, null=True, blank=True, verbose_name='دسته‌بندی')
    ingredients = models.TextField(verbose_name='مواد اولیه')
    instructions = models.TextField(verbose_name='دستور پخت')
    steps = models.TextField(verbose_name='مراحل')
    main_image = models.ImageField(upload_to="images/recipes/", verbose_name='تصویر اصلی')
    video = models.FileField(upload_to="videos/recipes/", blank=True, null=True, verbose_name='ویدیو آشپزی')  
    prep_time = models.IntegerField(help_text="زمان آماده‌سازی به دقیقه", verbose_name='زمان آماده‌سازی')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='تاریخ ایجاد')
    pdf_file = models.FileField(upload_to="pdf_files/", blank=True, null=True, verbose_name='فایل PDF')
    status = models.BooleanField(default=True, verbose_name='فعال/غیرفعال')
    views_count = models.PositiveIntegerField(default=0, verbose_name='تعداد بازدید')
    slug = models.SlugField(unique=True, blank=True)
    user_registered = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
 

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = 'دستور آشپزی'
        verbose_name_plural = 'دستورهای آشپزی'
        db_table = 't_Recipe'


class Rating(models.Model):
    recipe = models.ForeignKey(Recipe, on_delete=models.CASCADE, verbose_name='دستور آشپزی')
    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name='کاربر')
    value = models.PositiveSmallIntegerField(
        default=1,
        choices=[(i, str(i)) for i in range(1, 6)],
        verbose_name='امتیاز'
    )

    def __str__(self):
        return f"{self.recipe} - {self.value}"

    class Meta:
        verbose_name = 'امتیاز'
        verbose_name_plural = 'امتیازها'
        db_table = 't_Rating'
        unique_together = ('recipe', 'user')


def upload_gallery_image(instance, filename):
    return f"images/recipe/{instance.recipe.title}/gallery/{filename}"


class RecipeGallery(models.Model):
    image_name = models.ImageField(upload_to=upload_gallery_image, verbose_name='تصویر گالری')
    recipe = models.ForeignKey(Recipe, on_delete=models.CASCADE, verbose_name='دستور آشپزی')


class Like(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    recipe = models.ForeignKey(Recipe, on_delete=models.CASCADE, null=True, blank=True)

    class Meta:
        unique_together = ('user', 'recipe')
