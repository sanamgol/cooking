from rest_framework import serializers
from .models import Author, Category, Recipe, Rating, RecipeGallery, Like

# -----------------------
# Author Serializer
# -----------------------
class AuthorSerializer(serializers.ModelSerializer):
    class Meta:
        model = Author
        fields = '__all__'


# -----------------------
# Category Serializer
# -----------------------
class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = '__all__'


# -----------------------
# Recipe Serializer
# -----------------------
class RecipeSerializer(serializers.ModelSerializer):
    author = AuthorSerializer(read_only=True)
    category = CategorySerializer(read_only=True)

    class Meta:
        model = Recipe
        fields = '__all__'


# -----------------------
# Rating Serializer
# -----------------------
class RatingSerializer(serializers.ModelSerializer):
    recipe = RecipeSerializer(read_only=True)

    class Meta:
        model = Rating
        fields = '__all__'


# -----------------------
# RecipeGallery Serializer
# -----------------------
class RecipeGallerySerializer(serializers.ModelSerializer):
    recipe = RecipeSerializer(read_only=True)

    class Meta:
        model = RecipeGallery
        fields = '__all__'


# -----------------------
# Like Serializer
# -----------------------
class LikeSerializer(serializers.ModelSerializer):
    recipe = RecipeSerializer(read_only=True)
    user_liked = serializers.StringRelatedField()  # نام کاربر رو نمایش میده

    class Meta:
        model = Like
        fields = '__all__'


