# ==============================
# Standard Library Imports
# ==============================
import os
import datetime

# ==============================
# Django Imports
# ==============================
from django.conf import settings
from django.shortcuts import render, get_object_or_404, redirect
from django.views import View
from django.views.generic import ListView, DetailView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse
from django.http import (
    HttpResponse,
    HttpResponseNotFound,
    HttpResponseRedirect,
    JsonResponse,
)
from django.core.mail import EmailMultiAlternatives
from django.core.files.storage import FileSystemStorage
from django.core.paginator import Paginator
from django.contrib.auth.decorators import login_required

# ==============================
# Local Imports (Models & Forms)
# ==============================
from .models import (
    Author,
    Category,
    Recipe,
    Rating,
    Like as RecipeLike,
    RecipeGallery,
)
from .forms import RecipeForm, RecipeGalleryForm

# ==============================
# Accounts App Imports
# ==============================
from apps.accounts.serializers import PersonSerializer
from apps.accounts.models import PersonModel

# ==============================
# DRF Imports
# ==============================
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticatedOrReadOnly, AllowAny
from rest_framework.response import Response

from .serializers import (
    AuthorSerializer,
    CategorySerializer,
    RecipeSerializer,
    RatingSerializer,
    RecipeGallerySerializer,
    LikeSerializer,
)

# ===========================================================
# Author Views
# ===========================================================
class AuthorListView(ListView):
    model = Author
    template_name = "recipes/author_list.html"
    context_object_name = "authors"


class AuthorDetailView(DetailView):
    model = Author
    template_name = "recipes/author_detail.html"
    context_object_name = "author"


# ===========================================================
# Category Views
# ===========================================================
class CategoryListView(ListView):
    model = Category
    template_name = "recipes/category_list.html"
    context_object_name = "categories"


class CategoryDetailView(ListView):
    model = Recipe
    template_name = "recipes/category_detail.html"
    context_object_name = "recipes"

    def get_queryset(self):
        category_id = self.kwargs.get('id')
        return Recipe.objects.filter(category__id=category_id, status=True)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['category'] = Category.objects.get(id=self.kwargs.get('id'))
        return context


# ===========================================================
# Recipe Views
# ===========================================================
class RecipeListView(ListView):
    model = Recipe
    template_name = "recipes/recipe_list.html"
    context_object_name = "recipes"

    def get_queryset(self):
        return Recipe.objects.filter(status=True).order_by("-created_at")


class RecipeDetailView(DetailView):
    model = Recipe
    template_name = "recipes/recipe_detail.html"
    context_object_name = "recipe"
    slug_field = "slug"
    slug_url_kwarg = "slug"

    def get_object(self, queryset=None):
        recipe = super().get_object(queryset)
        recipe.views_count += 1
        recipe.save(update_fields=["views_count"])
        return recipe


def recipe_gallery(request, slug):
    recipe = get_object_or_404(Recipe, slug=slug)
    galleries = RecipeGallery.objects.filter(recipe=recipe).order_by('-id')
    context = {"recipe": recipe, "galleries": galleries}
    return render(request, "recipes/recipe_gallery.html", context)


# ===========================================================
# Recipe CRUD Views
# ===========================================================
class RecipeCreate(CreateView):
    model = Recipe
    fields = "__all__"

    def get_success_url(self):
        return reverse("recipes:recipe_list")


class RecipeUpdate(UpdateView):
    model = Recipe
    fields = "__all__"

    def get_success_url(self):
        return reverse("recipes:recipe_list")


class RecipeDelete(DeleteView):
    model = Recipe

    def get_success_url(self):
        return reverse("recipes:recipe_list")


# ===========================================================
# Pagination Example
# ===========================================================
def fun1(request):
    posts = Recipe.objects.order_by('is_activ')
    paginator = Paginator(posts, 3)
    page_number = request.GET.get('page')
    recipes = paginator.get_page(page_number)
    return render(request, 'recipes/recipe_list.html', {'recipes': recipes})


# ===========================================================
# File Download
# ===========================================================
def download_recipe(request):
    fs = FileSystemStorage()
    file_name = "pdf_files/cooking_units_conversion.pdf"
    if fs.exists(file_name):
        with fs.open(file_name) as pdf:
            response = HttpResponse(pdf, content_type="application/pdf")
            response['Content-Disposition'] = "attachment; filename=cooking_units_conversion.pdf"
            return response
    return HttpResponseNotFound('File not found ...')


# ===========================================================
# Email Helper
# ===========================================================
def sendEmail(subject, message, html_content, to):
    email_form = settings.EMAIL_HOST_USER
    message_obj = EmailMultiAlternatives(subject, message, email_form, to)
    message_obj.attach_alternative(html_content, "text/html")
    message_obj.send()


# ===========================================================
# Classic Recipe Form
# ===========================================================
def formrecipe(request):
    context = {}
    if request.method == "POST":
        form = RecipeForm(request.POST, request.FILES)
        if form.is_valid():
            pdff = request.FILES['pdf_file']
            imageUpload = request.FILES['main_image']
            videoUpload = request.FILES.get('video', None)

            if pdff.size <= 2 * 1024 * 1024 and pdff.content_type == "application/pdf":
                currenttime = datetime.datetime.utcnow().strftime("%Y%m%d%H")
                pdfname, pdfext = os.path.splitext(pdff.name)
                pdfpath = f'pdf_files/{pdfname}{currenttime}{pdfext}'

                imgName, ext = os.path.splitext(imageUpload.name)
                imagepath = f'images/recipes/{imgName}{currenttime}{ext}'

                if videoUpload:
                    videoname, videoext = os.path.splitext(videoUpload.name)
                    videopath = f'videos/recipes/{videoname}{currenttime}{videoext}'
                else:
                    videopath = None

                data = form.cleaned_data
                rc = Recipe(
                    title=data['title'],
                    ingredients=data['ingredients'],
                    instructions=data['instructions'],
                    steps=data['steps'],
                    main_image=imagepath,
                    video=videopath,
                    prep_time=data['prep_time'],
                    created_at=data['created_at'],
                    pdf_file=pdfpath,
                    status=data.get('status', True),
                    views_count=data.get('views_count', 0),
                )
                rc.save()

                fss = FileSystemStorage()
                fss.save(imagepath, imageUpload)
                fss.save(pdfpath, pdff)
                if videopath:
                    fss.save(videopath, videoUpload)

                sendEmail("رسپی", "", "دستور پخت با موفقیت درج شد", ["goolisanam@gmail.com"])
                return HttpResponseRedirect(reverse('recipes:recipe_list'))
            else:
                context = {"form": form, "message": "فایل باید PDF و کمتر از ۲ مگابایت باشد."}
    else:
        form = RecipeForm()

    context["form"] = form
    return render(request, "recipes/recipe_form.html", context)


# ===========================================================
# Like Recipe
# ===========================================================
@login_required
def like_recipe(request):
    if request.method == 'GET':
        recipe_id = request.GET.get("recipe_id")
        recipe = Recipe.objects.get(id=recipe_id)
        likepost = RecipeLike.objects.filter(recipe=recipe, user=request.user)
        if not likepost.exists():
            likepost = RecipeLike(recipe=recipe, user=request.user)
            likepost.save()
        return JsonResponse({"status": "success", "recipe_id": recipe_id})
    return JsonResponse({"status": "unsuccess"})


# ===========================================================
# Show Recipe (with liked)
# ===========================================================
class ShowRecipe(View):
    def get(self, request, *args, **kwargs):
        recipes = Recipe.objects.filter(status=True)
        liked_ids = []
        if request.user.is_authenticated:
            liked_ids = [like.post.id for like in RecipeLike.objects.filter(user_liked=request.user)]
        return render(request, "recipes/show_recipe.html", {"recipes": recipes, "liked_ids": liked_ids})


# ===========================================================
# Rating API
# ===========================================================
@login_required
def add_rating(request, recipe_id):
    recipe = get_object_or_404(Recipe, pk=recipe_id)
    if request.method == "POST":
        value = request.POST.get("value")
        if value:
            Rating.objects.update_or_create(recipe=recipe, user=request.user, defaults={"value": value})
        return redirect("recipe_detail", pk=recipe.id)
    return render(request, "recipes/rating_form.html", {"recipe": recipe})


# ===========================================================
# Person API
# ===========================================================
class Personlist(APIView):
    permission_classes = [IsAuthenticatedOrReadOnly]

    def get(self, request):
        people = PersonModel.objects.all()
        ser_data = PersonSerializer(instance=people, many=True)
        return Response(data=ser_data.data)


# ===========================================================
# Index Recipes
# ===========================================================
def index_recipes(request):
    recipes = Recipe.objects.all()
    return render(request, "recipes/index.html", {"recipe": recipes})


# ===========================================================
# Author / Category / Recipe / Rating / Gallery / Like APIs
# ===========================================================
class AuthorListAPI(APIView):
    permission_classes = [IsAuthenticatedOrReadOnly]

    def get(self, request):
        authors = Author.objects.all()
        ser_data = AuthorSerializer(instance=authors, many=True)
        return Response(data=ser_data.data)


class CategoryListAPI(APIView):
    permission_classes = [IsAuthenticatedOrReadOnly]

    def get(self, request):
        categories = Category.objects.all()
        ser_data = CategorySerializer(instance=categories, many=True)
        return Response(data=ser_data.data)


class RecipeListAPI(APIView):
    permission_classes = [IsAuthenticatedOrReadOnly]

    def get(self, request):
        recipes = Recipe.objects.all()
        ser_data = RecipeSerializer(instance=recipes, many=True)
        return Response(data=ser_data.data)


class RatingListAPI(APIView):
    permission_classes = [IsAuthenticatedOrReadOnly]

    def get(self, request):
        ratings = Rating.objects.all()
        ser_data = RatingSerializer(instance=ratings, many=True)
        return Response(data=ser_data.data)


class RecipeGalleryListAPI(APIView):
    permission_classes = [IsAuthenticatedOrReadOnly]

    def get(self, request):
        galleries = RecipeGallery.objects.all()
        ser_data = RecipeGallerySerializer(instance=galleries, many=True)
        return Response(data=ser_data.data)


class LikeListAPI(APIView):
    permission_classes = [IsAuthenticatedOrReadOnly]

    def get(self, request):
        likes = RecipeLike.objects.all()
        ser_data = LikeSerializer(instance=likes, many=True)
        return Response(data=ser_data.data)
