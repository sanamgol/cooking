from django import forms
from .models import Author, Category, Recipe, RecipeGallery

from django.core.exceptions import ValidationError






def checkimage(value):
    if value.size > 2*1024*1024:  
        raise forms.ValidationError("حجم تصویر نباید بیشتر از ۲ مگابایت باشد.")
    valid_types = ["image/jpeg", "image/png"]
    if value.content_type not in valid_types:
        raise forms.ValidationError("فرمت تصویر فقط باید JPEG یا PNG باشد.")



def checkvideo(value):
    if value.size > 10*1024*1024: 
        raise forms.ValidationError("حجم ویدیو نباید بیشتر از ۱۰ مگابایت باشد.")
    
      
    
    
    
class RecipeForm(forms.Form):
        
            title = forms.CharField(max_length=200, required=True, label="عنوان")
            author = forms.ModelChoiceField(queryset=Author.objects.all(), required=False, label="نویسنده")
            category = forms.ModelChoiceField(queryset=Category.objects.all(), required=True, label="دسته‌بندی")

            ingredients = forms.CharField(widget=forms.Textarea, required=True, label="مواد اولیه")
            instructions = forms.CharField(widget=forms.Textarea, required=True, label="دستور پخت")
            steps = forms.CharField(widget=forms.Textarea, required=True, label="مراحل")
            main_image = forms.ImageField(
            validators=[checkimage],
            required=True,
            label="تصویر اصلی",
            widget=forms.ClearableFileInput(attrs={'class': 'c1'})
        )

            video = forms.FileField(
            validators=[checkvideo],
            required=False,
            label="ویدیو آشپزی",
            widget=forms.ClearableFileInput(attrs={'class': 'c1'})
        )

            prep_time = forms.IntegerField(min_value=1, required=True, label="زمان آماده‌سازی (دقیقه)")
           
            pdf_file = forms.FileField(required=False, label="فایل PDF")
            status = forms.BooleanField(initial=True, required=False, label="فعال/غیرفعال")
           

            def clean_title(self):
                title = self.cleaned_data["title"]
                if len(title) < 3:
                    raise ValidationError("عنوان باید حداقل ۳ کاراکتر باشد.")
                return title

            def clean_author(self):
                author = self.cleaned_data["author"]
                return author

            def clean_category(self):
                category = self.cleaned_data["category"]
                return category

            def clean_ingredients(self):
                ingredients = self.cleaned_data["ingredients"]
                if len(ingredients) < 5:
                    raise ValidationError("مواد اولیه خیلی کوتاه است.")
                return ingredients

            def clean_instructions(self):
                instructions = self.cleaned_data["instructions"]
                return instructions

            def clean_steps(self):
                steps = self.cleaned_data["steps"]
                return steps

            def clean_main_image(self):
                image = self.cleaned_data["main_image"]
                return image

            def clean_video(self):
                video = self.cleaned_data.get("video")
                return video

            def clean_prep_time(self):
                prep_time = self.cleaned_data["prep_time"]
                if prep_time <= 0:
                    raise ValidationError("زمان آماده‌سازی باید بزرگتر از صفر باشد.")
                return prep_time

            
            def clean_pdf_file(self):
                pdf_file = self.cleaned_data.get("pdf_file")
                return pdf_file

            def clean_status(self):
                status = self.cleaned_data.get("status", True)
                return status

            
  
  
class  RecipeGalleryForm(forms.ModelForm):
    class Meta:
        model=RecipeGallery
        fields=['image_name']
    
    
    
    
    
               
                    