from django.views import View
from django.db.models import Q
from django.shortcuts import render
from apps.recipes.models import Recipe
from apps.CookingClasses.models import CookingClass



from django.shortcuts import render
from apps.recipes.models import Recipe

def search_results(request):
    query = request.GET.get('q')
    results = Recipe.objects.filter(title__icontains=query) if query else Recipe.objects.none()
    return render(request, 'Search/search_results.html', {'results': results, 'query': query})
